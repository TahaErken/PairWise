from allpairspy import AllPairs

parameters = [
    ["ASUS", "PHILIPS"],
    ["98", "NT", "2000", "XP"],
    ["Internal", "Modem","aslan"],
    ["Salaried", "Hourly", "Part-Time", "Contr."],
    [6, 10, 15, 30, 60,2,34,45,32],
]

print("PAIRWISE:")
for i, pairs in enumerate(AllPairs(parameters)):
    print("{:2d}: {}".format(i, pairs))
